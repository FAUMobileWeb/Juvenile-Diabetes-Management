var slider1 = $('#slider-1').slider({
    formatter: function (value) {
        return 'Val:' + value;
    }
});
var slider2 = $('#slider-2').slider({
    formatter: function (value) {
        return 'Val: ' + value;
    }
});
var slider3 = $('#slider-3').slider({
    formatter: function (value) {
        return 'Val: ' + value;
    }
});
var slider4 = $('#slider-4').slider({
    formatter: function (value) {
        return 'Val: ' + value;
    }
});