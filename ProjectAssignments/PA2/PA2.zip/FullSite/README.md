#Project Assignment 2
A progress on our Juvenile Diabetes Management website.

Illustrates most of the basic webpages being used.