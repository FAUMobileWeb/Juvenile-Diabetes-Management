#Project Assignment 3
A progress on our Juvenile Diabetes Management website.

The complete website runable locally